//META{"name":"getLang"}*//
var getLang = function() {};

getLang.prototype.inject = function() {
  setTimeout(function(){
	  $("code.hljs").each(function() {
		if (!$(this).find('.langlbl').length) {
		  $(this).css({
			"position": "relative"
		  });
          var lang = $(this).attr('class').split(' hljs ')[1];
		  var label = $(`<div>${lang}</div>`).addClass("langlbl").css({
			"color": "#839496",
			"border": "2px solid #282b30",
			"background-color": "#2e3136",
			"position": "absolute",
			"left": "0",
			"top": "0"
		  });
          if (lang !== undefined){
              $(this).append(label);
          }
		}
	  });
  }, 100);
};

getLang.prototype.observer = function(e) {
  this.inject();
};

getLang.prototype.start = function() {
  this.inject();
};

getLang.prototype.load = function() {
  this.inject();
 };

getLang.prototype.getSettingsPanel = function() {
  return "";
};

getLang.prototype.getName = function() {
  return "Get Language Plugin";
};

getLang.prototype.getDescription = function() {
  return "Gets language from Code Blocks";
};

getLang.prototype.getVersion = function() {
  return "0.0.1";
};

getLang.prototype.getAuthor = function() {
  return "•MGC•Mr_ChAI#7272";
};

getLang.prototype.remove = function() {
  $("code.hljs").css({
    "position": ""
  });
  $(".langlbl").remove();
};

getLang.prototype.stop = function() {
    $("code.hljs").css({
      "position": ""
    });
    $(".langlbl").remove();
};
getLang.prototype.unload = function() {
    $("code.hljs").css({
      "position": ""
    });
    $(".langlbl").remove();
};
getLang.prototype.disable = function() {
    $("code.hljs").css({
      "position": ""
    });
    $(".langlbl").remove();
};
