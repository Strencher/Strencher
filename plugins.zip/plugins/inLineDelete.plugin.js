//META{"name":"InLineDelete"}*//
class InLineDelete {
  getName() { return "!!!!InLineDelte"; }
  getAuthor() { return "Strencher"; }
  getDescription() { return "Let you delete messages inline"; }
  getVersion() { return "0.0.1"; }
  load() { }
  unload() { }
  onSwitch() {
      this.buttonDelete()
    
    
  }


  start() {
    let style = `
      .inlineKick {
        visibility: hidden;
      }
      .inlineDelte {
        visibility: hidden !important;
      }
      .markup-2BOw-j:hover .inlineDelete  {
        visibility: visible !important;
      }
      .markup-2BOw-j:hover .inlineKick {
        visibility: visible !important;
      }
      
      `
    BdApi.injectCSS("inlineDelete", style);
      this.buttonDelete()
    
    
    
  }
  onChange() {
    if(document.getElementsByClassName("markup-2BOw-j")[0].classList === "inlineDelete") {
      return;
    } else {
      this.buttonDelete();
    }
  }

  removeAll() {
    let s1 = document.getElementsByClassName("inlineDelete");
    s1.style = "display: none;"
  }


  buttonKick() {
    let bars = document.querySelectorAll(".markup-2BOw-j:not(.slateTextArea-1bp44y)");
    for (let bar of bars) {

      let Icon = document.createElement("img");
      let buttonKick = document.createElement("button");
      let buttonKickInner = document.createElement("div");
      bar.appendChild(buttonKick);
      buttonKick.appendChild(buttonKickInner);
      buttonKickInner.appendChild(Icon);
      buttonKick.setAttribute("class", "inlineKick");
      buttonKickInner.setAttribute("style", "background-color: transparent !important;");
      buttonKick.setAttribute("style", "background-color: transparent !important;");
      Icon.setAttribute("style", "transform: scale(1) !important; filter: invert(70%) !important");
      Icon.setAttribute("width", "13");
      Icon.setAttribute("height", "13");
      Icon.setAttribute("class", "inlineKick");
      buttonKickInner.setAttribute("class", "inlineKick");
      Icon.setAttribute("class", "inlineKick");

      buttonKick.onclick = () => {
        this.alertText();
      }

      Icon.onmouseover = () => {
        Icon.setAttribute("style", "transform: scale(1.2) !important; filter: invert(100%) !important");

      }
      Icon.onmouseout = () => {
        Icon.setAttribute("style", "transform: scale(1) !important; filter: invert(70%) !important");
      }
      Icon.setAttribute("src", "https://image.flaticon.com/icons/svg/149/149409.svg");
    }
  }
  alertText(callbackOk, callbackCancel) {
  let backdrop = $(`<div class="backdrop-1wrmKB da-backdrop" style="opacity: 0.85; background-color: rgb(0, 0, 0); z-index: 1000; transform: translateZ(0px);"></div>`);
  let a =  $(`<div class="modal-3c3bKg da-modal" style="opacity: 1; transform: scale(1) translateZ(0px); z-index: 9999999">
          <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
          <div data-focus-guard="true" tabindex="1" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
          <div data-focus-lock-disabled="false" class="inner-1ilYF7 da-inner">
            <div class="modal-yWgWj- da-modal container-14fypd da-container sizeSmall-1jtLQy">
              <div class="scrollerWrap-2lJEkd firefoxFixScrollFlex-cnI2ix da-scrollerWrap da-firefoxFixScrollFlex content-1EtbQh da-content scrollerThemed-2oenus da-scrollerThemed themeGhostHairline-DBD-2d">
                <div class="scroller-2FKFPG firefoxFixScrollFlex-cnI2ix da-scroller da-firefoxFixScrollFlex systemPad-3UxEGl da-systemPad inner-ZyuQk0 da-inner content-dfabe7 da-content">
                  <h2 class="h2-2gWE-o title-3sZWYQ size16-14cGz5 height20-mO2eIN weightSemiBold-NJexzi da-h2 da-title da-size16 da-height20 da-weightSemiBold defaultColor-1_ajX0 da-defaultColor title-18-Ds0 marginBottom20-32qID7 marginTop8-1DLZ1n da-title da-marginBottom20 da-marginTop8">
                    Möchtest du ihn wirklick kicken?
                  </h2>
                  <div class="inputWrapper-31_8H8 da-inputWrapper">
                  <div class="inputMaxLength-1vRluy da-inputMaxLength">
                  <textarea type="text" class="strKickenInput inputDefault-_djjkz input-cIJ7To da-inputDefault da-input textArea-1Lj-Ns da-textArea scrollbarDefault-3COgCQ scrollbar-3dvm_9 da-scrollbarDefault da-scrollbar" placeholder="Grund für den Kick:" maxlength="512" rows="2"></textarea>
                  </div>
                  </div>
                </div>
              </div>
              <div class="flex-1xMQg5 flex-1O1GKY da-flex da-flex horizontalReverse-2eTKWD horizontalReverse-3tRjY7 flex-1O1GKY directionRowReverse-m8IjIq justifyBetween-2tTqYu alignStretch-DpGPf3 wrap-ZIn9Iy footer-3rDWdC da-footer" style="flex: 0 0 auto;">
                <button class="strAbbrechen button-38aScr da-button lookLink-9FtZy- colorPrimary-3b3xI6 sizeMedium-1AC_Sl grow-q77ONN da-grow">
                  <div class="contents-18-Yxp da-contents">Abbrechen</div>
                </button>
                <button class="strKicken button-38aScr da-button lookFilled-1Gx00P colorRed-1TFJan sizeMedium-1AC_Sl grow-q77ONN da-grow">
                <div class="contents-18-Yxp da-contents">Kicken</div>
              </div>
            </div>
          </div>
          <div data-focus-guard="true" tabindex="0" style="width: 1px; height: 0px; padding: 0px; overflow: hidden; position: fixed; top: 1px; left: 1px;"></div>
        </div>`);
  a.find(".strAbbrechen").on("click", () => {
    if(typeof callbackOk === "function") callbackOk();
      a.remove();
      backdrop.remove();
  });
  a.find(".strKicken").on("click", () => {
    this.doKick();
    window.setTimeout(() => {
      a.remove();
      backdrop.remove();
    }, 100);
  });
  backdrop.on("click", () => {
    if(typeof callbackCancel === "function") callbackCancel();
      a.remove();
      backdrop.remove();
  });
  backdrop.appendTo("#app-mount > div[data-no-focus-lock='true'] > div:not([class])");
  a.appendTo("#app-mount > div[data-no-focus-lock='true'] > div:not([class])");
  return a.find("div.da-modal")[0];
}
  doKick(msgEl) {
    let props = ZLibrary.ReactTools.getOwnerInstance(msgEl).props;
    let guildID = props.channel.guild_id;
    let grund = document.getElementsByClassName("strKickenInput")[0].value;
    let userId = props.message.author.id;
    ZLibrary.DiscordModules.GuildActions.kickUser(guildID, userId, grund);
  }

  buttonDelete() {
    let bars = document.querySelectorAll(".markup-2BOw-j:not(.slateTextArea-1bp44y)");
    for (let bar of bars) {

      let Icon = document.createElement("img");
      let buttonDelete = document.createElement("button");
      let buttonDeleteInner = document.createElement("div");
      bar.appendChild(buttonDelete);
      buttonDelete.appendChild(buttonDeleteInner);
      buttonDeleteInner.appendChild(Icon);
      buttonDelete.setAttribute("class", "inlineDelete");
      buttonDeleteInner.setAttribute("style", "background-color: transparent !important;");
      buttonDelete.setAttribute("style", "background-color: transparent !important;");
      Icon.setAttribute("style", "transform: scale(1) !important; filter: invert(70%) !important");
      Icon.setAttribute("width", "13");
      Icon.setAttribute("height", "13");
      Icon.setAttribute("class", "inlineDelete");
      buttonDeleteInner.setAttribute("class", "inlineDelte");
      Icon.setAttribute("class", "inlineDelete");

      buttonDelete.onclick = () => {
        this.doDelete(bar);
      }

      Icon.onmouseover = () => {
        Icon.setAttribute("style", "transform: scale(1.2) !important; filter: invert(100%) !important");

      }
      Icon.onmouseout = () => {
        Icon.setAttribute("style", "transform: scale(1) !important; filter: invert(70%) !important");
      }
      Icon.setAttribute("src", "https://image.flaticon.com/icons/svg/1214/1214428.svg");
    }
  }
  

  doDelete(msgEl) {
    let message = ZLibrary.ReactTools.getOwnerInstance(msgEl).props.message;
    let channelId = message.channel_id;
    let messageId = message.id;
    ZLibrary.DiscordModules.MessageActions.deleteMessage(`${channelId}`, `${messageId}`);
  }
  stop() { BdApi.clearCSS("inlineDelete"); this.removeAll();}


}
