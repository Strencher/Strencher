//META{"name":"fixPlugin"}*//

class fixPlugin{
    getName() { return "BetterFormatingRedux and Quoter fix"; }
    getAuthor() { return "Strencher"; }
    getDescription() { return "A fix about the two plugins"; }
    getVersion() { return "0.0.1"; }

    load() {
    }
    unload() {
        BdApi.clearCSS(this.getName());
    }
    start() {
        var myCss = `
        .btn-quote {
            z-index: 10000;
            background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABmJLR0QA/wD/AP+gvaeTAAABaUlEQVQ4jWNgGGjAuLBnWy47D6c5usTPrz+exxd7ljIwMDAs7N3ezc7NIYmh5sv3kyzsPJzmJrbG0eiSV89ePQJjC4gKWGgba9ugqzlz+CwDE6VeGAYGsPz8+uM5coBJyEpaCooIMLOws+rDxD68/fACpubf3388Kjqq+mzsrIxMzEyWKKZ1lM/kP7D5+ss7Vz/9Xz//8A5sNk5qXOV96cTz/3eufvq/bOqeGSheEOIX8xMSExT5/+8fw7cv329jM0CQn9+Lk4eL4euXb3+/ffl2lAUmMbNji7eMgkQZFw8X0+0rt+++/vSmBVljQ0MDkwKvaaasipw/IwMjw+0rt04++X5uKdwASWnhaQpqCnLXzl+/+vLpi8KC6qiXyAbwfFYwVLdWn8DFy8N4/vj5Yy9efIxpaGj4Bzfg1fPX+169fH3pyZfnMxsa0r+hO/0PC9Pr21fvLfn54/vepz/OL2toaPiHzYv0BwAdppQnHPc1vAAAAABJRU5ErkJggg==) !important;
        }
        .bf-toolbar .bf-arrow {
            background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAZCAYAAADE6YVjAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAALiIAAC4iAari3ZIAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAAB3RJTUUH4wkaDjcw0vCrlAAAAYRJREFUSEvtk71Lw1AUxTNU0cnBwcFBXAQdFHQWF2cHRXB2cHSXov4HdXBwdhBJnYot6OBeU8HJoQiCQ2htu9h8Nh/V89LjKwGLVis45Achefeee3Lv4z0lIeF/oKrqSLlcXuBy8DSbzWXf9x/egOd5V5VKZYqpwWDb9l4QBKH4wQdY11zXXafk5zQajckwDC/p+ynIH2Wz2SGW9IdlWWsw0OklwVa5/JRgGzXTNOdZ+jWlUinlOE6G9TFgdFCtVqeRP2dIgoZMNLBDm94YhjHXarVuWSeBwRNyq5RFCENhTIkE8TO8xiiLA/Ptdrv92pF2QdGFruvjlMUQW4QDcEepBLFHTLtCmaIgloLRaSfdBUIX3e9S1pNCoTCMU3bMMgkaDuGbjkSY4IZxCX5wX6/XlyLBN8Ex38QBqNFCAv9DMUkMdHWSy+VGWdsX4oKiwWtaReASP4tJMhhNmL+gmy3qfwV89uHr4Qkw3UYULBaLi/l8fiJaDAhN02bgO8tlQsKfoCjvD179CqD5kFoAAAAASUVORK5CYII=) !important;
          }
        `;
        BdApi.injectCSS(this.getName(), myCss);
    }
    stop() {
        BdApi.clearCSS(this.getName());
    }
    getSettingsPanel() {return}
} 