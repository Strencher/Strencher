//META{"name":"test"}*//

class test {

    getName() {return "!!!!!!!1!test";}
    getAuthor() {return "Strencher";}
    getDescription() {return "its a test";}
    getVersion() {return "0.0.1";}

    load() {this.loadSettings()}
    unload() {}
    onSwitch() {this.test()}

   test() {
   }
   initialize() {
    this.loadSettings()
  }

    start() {}
    getSettingsPanel() {
        let settings = ZLibrary.PluginUtilities.loadSettings("testing", {});
        let panel = $(`<form class="form" style="width:100%;"></form>`)[0];
        let a = document.createElement("input");
        a.setAttribute("type", "color");
        a.setAttribute("class", "testing");
        a.setAttribute("value", `${settings.test}`);
        window.setTimeout(() => {
            let changes = document.getElementsByClassName("testing")[0].value;
            changes.addEventListener("change", (e) => {
                settings.test = e;
                this.saveSettings();
            });
            
        }, 1000);
        panel.appendChild(a);
        return panel;
    }
    defaultSettings() {
        return {
            "test":"#9900FF",
        }
    }
    saveSettings() {
        ZLibrary.PluginUtilities.saveSettings("testing", this.settings);
    }
      loadSettings() {
        this.settings = ZLibrary.PluginUtilities.loadSettings("testing", this.defaultSettings());
    }
stop() {}
}