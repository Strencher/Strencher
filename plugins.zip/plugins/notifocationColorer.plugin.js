//META{"name":"notificationColorer"}*//

class notificationColorer {
    getName() {return "!Notification Colorer"};
    getAuthor() {return "Strencher"};
    getDescription() {return "Colors for you the toast (Notifications)"};
    getVersion() {return "0.0.1"};


    load() {return}
    unload() {return} 
    start() {
        
        const settingsCss = `
        .input-notificolor {
            background-color: #1a1919;
            border-color: #222222;
            border-radius: 14px;
            color: white;
        }
        .title-notificolor {
            color: white;
            font-size: 20px;
            font-weight: bold;
            margin-left: 160px;
            margin-bottom: 50px;
        }`;
        BdApi.injectCSS(this.getName(), settingsCss);
    }
    stop() {
        BdApi.clearCSS(this.getName());
    }
    getSettingsPanel() {

         
        let title = document.createElement("div");
        let wrapper = document.createElement("div");
        let inputInfo = document.createElement("input");
        let testInfo = document.createElement("button");
        inputInfo.setAttribute("style", "color: white; background-color: #1a1919;");
        title.addEventListener("test", ()=>{});
        testInfo.innerHTML = "Test Info toast";
        testInfo.className = "lookFilled-1Gx00P colorBrand-3pXr91";
        testInfo.onmouseover = () => {
            testInfo.style = "transform: scale(1)";
        }
        testInfo.onmousout = () => {
            testInfo.style = "transform: scale(0)";
        }
        testInfo.onclick = () => {
            BdApi.showToast("This is the test Info toast.", {type: "info"});
        }
        title.innerHTML = "Notification Colorer Theme Settings";
        title.className = `title-notificolor`;
        wrapper.appendChild(title);   
        wrapper.appendChild(inputInfo);
        wrapper.appendChild(testInfo);
        return wrapper;
    }
}