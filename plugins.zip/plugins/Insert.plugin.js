//META{"name":"insertText"}*//
class insertText {
    getName() {
        return "Insert Text";
    }
    getAuthor() {
        return "Strencher";
    }
    getDescription() {
        return "-";
    }
    getVersion() {
        return "0.0.0";
    }

    start() {
        $(".hljs").on("contextmenu", () => {

            window.setTimeout(() => {
                if(document.getElementsByClassName("insertText")[0]) {
                    return;
                } else {
                    this.contextMenu()
                }
            }, 3);

        })
    }
    
    stop() {}
    contextMenu() {
        let base = document.getElementsByClassName("contextMenu-HLZMGh")[0];
        let s1 = document.createElement("div");
        let s2 = document.createElement("div");
        let s3 = document.createElement("div");
        let s4 = document.createElement("div");
        s1.setAttribute("class", "itemGroup-1tL0uz da-itemGroup");
        s2.setAttribute("tabindex", "0");
        s2.setAttribute("class", "insertText item-1Yvehc itemBase-tz5SeC da-item da-itemBase clickable-11uBi- da-clickable");
        s2.setAttribute("role", "menuitem");
        s3.setAttribute("class", "label-JWQiNe da-label");
        s3.innerHTML = "Text Einfügen";
        s4.setAttribute("class", "hint-22uc-R da-hint");
        base.insertBefore(s1, base.firstChild);
        s1.appendChild(s2);
        s2.appendChild(s3);
        s3.appendChild(s4);
        
    
}
            contextMenu1() {
                let a = $(`
                <div tabindex="0" class="insertText item-1Yvehc itemBase-tz5SeC da-item da-itemBase clickable-11uBi- da-clickable" role="menuitem">
                <div class="label-JWQiNe da-label">Test</div><div class="hint-22uc-R da-hint">
                </div>
                </div>`);
                window.setTimeout(() => {
                    a.appenTo(".itemGroup-1tL0uz");
                    
                }, 1);
            }
            action() {
            let text = document.querySelectorAll(".markup-2BOw-j").innerText;
            let area = document.getElementsByClassName("textArea-2Spzkt")[0];
            area.value = text;
    }
}
