//META{"name":"betterdarkTheme"}*//

class betterdarkTheme {
  getAuthor() { return "Strencher"; }
  getName() { return "!BetterDarkTheme"; }
  getVersion() { return "0.0.1"; }
  getDescription() { return "A BetterDarkTheme"; }

  name() { return "BetterDarkTheme"; }
  load() {
    this.loadSettings()
  }
  unload() { }
  initialize() {
    this.loadSettings()
  }
  stop() {
    BdApi.clearCSS("BetterDarkTheme");
  }
  getSettingsPanel() {
    let panel = $(`<form class="form" style="width:100%;"></form>`)[0];
    new ZLibrary.Settings.SettingGroup(this.name(), { shown: true }).appendTo(panel)
      .append(
        new ZLibrary.Settings.Switch("Important", "This adds !important to classes.", this.settings.important, (e) => {
          this.changeColor();
          this.settings.important = e;
          this.saveSettings();
          this.reload();
        })
      )
      .append(
        new ZLibrary.Settings.Textbox("Accent Color", "The accent color of the theme.", this.settings.AccentColor, (e) => {
          this.changeColor();
          this.settings.AccentColor = e;
          this.saveSettings();
          this.reload();
        })
      )
      .append(
        new ZLibrary.Settings.Textbox("Mentioned Color", "The color of the edge of an Mention.", this.settings.Mentionedcolor, (e) => {
          this.changeColor();
          this.settings.Mentionedcolor = e;
          this.saveSettings();
          this.reload();
        })
      )
      .append(
        new ZLibrary.Settings.Textbox("Mentioned Background", "The Background Color of an Mention.", this.settings.MentionedBackground, (e) => {
          this.changeColor();
          this.settings.MentionedBackground = e;
          this.saveSettings();
          this.reload();
        })
      )
      .append(
        new ZLibrary.Settings.Textbox("Link Color", "The Color of Links eg. https://betterdiscord.net", this.settings.LinkColor, (e) => {
          this.changeColor();
          this.settings.LinkColor = e;
          this.saveSettings();
          this.reload();
        })
      )
      .append(
        new ZLibrary.Settings.Textbox("Mentioned Text font", "The font of an Mention.", this.settings.MentionedTextFont, (e) => {
          this.changeColor();
          this.settings.MentionedTextFont = e;
          this.saveSettings();
          this.reload();
        })
      )
      .append(
        new ZLibrary.Settings.Textbox("Channels Color", "The Color of channels eg. Voice & Text", this.settings.ChannelsColor, (e) => {
          this.changeColor();
          this.settings.ChannelsColor = e;
          this.saveSettings();
          this.reload();
        })
      )
      .append(
        new ZLibrary.Settings.Textbox("Unread Messages Wrapper", "The Background color of 'New Messages' (the jumper)", this.settings.UnreadMessagesWrapper, (e) => {
          this.changeColor();
          this.settings.UnreadMessagesWrapper = e;
          this.saveSettings();
          this.reload();
        })
      )
      .append(
        new ZLibrary.Settings.Textbox("Code Blocks", "The Background color of Code Blocks", this.settings.CodeBlock, (e) => {
          this.changeColor();
          this.settings.CodeBlock = e;
          this.saveSettings();
          this.reload();
        })
      )
      .append(
        new ZLibrary.Settings.Textbox("Channel msg Background", "The Background of an #test-channels wrapper in a message.", this.settings.ChannelColor, (e) => {
          this.changeColor();
          this.settings.ChannelColor = e;
          this.saveSettings();
          this.reload();
        })
      )
      .append(
        new ZLibrary.Settings.Textbox("Block Quote Edges", "The Color from the Edges of BlockQuotes", this.settings.BlockQuotes, (e) => {
          this.changeColor();
          this.settings.BlockQuotes = e;
          this.saveSettings();
          this.reload();
        })
      )


    return panel;

  }
  reload() {
    window.setTimeout(() => {
      pluginModule.reloadPlugin(`${this.getName()}`);
    }, 120);
  }
  defaultSettings() {
    return {
      important: false,
      lastUsedVersion: "0.0.0",
      Mentionedcolor: "#ff0000",
      MentionedBackground: "rgba(255,0,0,0.2)",
      LinkColor: "#34F141",
      MentionedTextFont: "Aial",
      ChannelsColor: "#8e9297",
      UnreadMessagesWrapper: "#808080",
      CodeBlock: "#000000",
      ChannelBackground: "rgba(235,3,3,.2)",
      ChannelColor: "#ffffff",
      BlockQuotes: "#9900ff",
      AccentColor: "#9900ff"
    }

  }
  saveSettings() {
    ZLibrary.PluginUtilities.saveSettings("BetterDarkTheme", this.settings);
  }
  loadSettings() {
    this.settings = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", this.defaultSettings());
  }
  
  changeColor() {
    this.selectors();
  }
  start() {
    this.changeColor()
    let libraryScript = document.getElementById("ZLibraryScript");
    if (!libraryScript || !window.ZLibrary) {
      if (libraryScript) libraryScript.parentElement.removeChild(libraryScript);
      libraryScript = document.createElement("script");
      libraryScript.setAttribute("type", "text/javascript");
      libraryScript.setAttribute("src", "https://rauenzi.github.io/BDPluginLibrary/release/ZLibrary.js");
      libraryScript.setAttribute("id", "ZLibraryScript");
      document.head.appendChild(libraryScript);
    }

    if (window.ZLibrary) this.initialize();
    else libraryScript.addEventListener("load", () => { this.initialize(); });

  }
  aaset() {
    let z = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
  z.important;}
  

  AccentColor() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.AccentColor;
  }
  
  Mentionedcolor() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.Mentionedcolor;
  }
  MentionedBackground() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.MentionedBackground;
  }
  LinkColor() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.LinkColor;
  }
  MentionedTextFont() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.MentionedTextFont;
  }
  ChannelsColor() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.ChannelsColor;
  }
  UnreadMessagesWrapper() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.UnreadMessagesWrapper;
  }
  CodeBlock() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.CodeBlock;
  }
  ChannelBackground() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.ChannelBackground;
  }
  ChannelColor() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.ChannelColor;
  }
  BlockQuotes() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    settings1.BlockQuotes;
  }
  selectors() {
    let settings1 = ZLibrary.PluginUtilities.loadSettings("BetterDarkTheme", {});
    let f = `
      .inner-zqa7da {
        border-radius: 11px ${settings1.important};
      }
          .textArea-2Spzkt {
            background-color: #222222 ${settings1.important};
            color: white ${settings1.important};
            border-color: #222222 ${settings1.important};
          }
          .attachButton-1UjEWA {
            background-color: #1B1B1B ${settings1.important};
            border-top-left-radius: 25px ${settings1.important};
            border-bottom-left-radius: 25px ${settings1.important};
          }
          .buttonContainer-21MN7J, .buttons-205you {
            background-color: #1B1B1B ${settings1.important};
            border-top-right-radius: 25px ${settings1.important};
            border-bottom-right-radius: 25px ${settings1.important};
          }
          
          .theme-dark .searchBar-3dMhjb {
            color: white ${settings1.important};
            background-color: #222222 ${settings1.important};
            border-top-left-radius: 11px ${settings1.important};
            border-top-right-radius: 11px ${settings1.important};
            border-bottom-left-radius: 11px ${settings1.important};
            border-bottom-right-radius: 11px ${settings1.important};
          }
          .theme-dark .name-3_Dsmg, .theme-light .name-3_Dsmg {
            color: ${settings1.ChannelsColor} ${settings1.important};
          }
          .channels-Ie2l6A {
            background-color: #252525 ${settings1.important};
          }
          .flexChild-faoVW3, .da-flexChild {
            background-color: #222222 ${settings1.important};
          }
          .theme-dark .menu-Sp6bN1 {
            background-color: #101010 ${settings1.important};
          }
          .theme-dark:hover .menu-Sp6bN1:hover {
            background-color: #101010 ${settings1.important};
          }
          .popoutBottom-2GAFPg.noArrow-2foL9g, .popoutBottomLeft-1pG8B4.noArrow-2foL9g, .popoutBottomRight-2Rno5S.noArrow-2foL9g {
            border-radius: 20px;
          }
          .theme-dark .markup-2BOw-j code, .theme-dark .markup-2BOw-j code.inline {
            background: ${settings1.CodeBlock}${settings1.important};
            border-color: grey ${settings1.important};
          
          }
          .langlbl {
            background-color: ${settings1.CodeBlock}${settings1.important};
            color: white ${settings1.important};
          }
          .theme-dark .isMentioned-N-h9aa {
            background-color: ${settings1.MentionedBackground} ${settings1.important};
            border-left-color: ${settings1.AccentColor} ${settings1.important};
          }
          .isMentionedCozy-3isp7y:after {
            border-left-color: ${settings1.Mentionedcolor} ${settings1.important};
          }
          .theme-dark .messagesWrapper-3lZDfY {
            background-color: #252525 ${settings1.important};
          }
          
          .theme-dark .container-1r6BKw {
            background-color: #1B1B1B ${settings1.important};
          }
          .scroller-2FKFPG, .theme-dark .bodyInner-245q0L {
            background-color: #252525 ${settings1.important};
          }
          .theme-dark .chat-3bRxxu, .theme-dark .chat-3bRxxu form, .theme-dark .content-yTz4x3 {
            background-color: #222222 ${settings1.important};
          }
          .theme-dark, .textArea-2Spzkt, .textArea-2Spzkt::-webkit-input-placeholder{
            color: white ${settings1.important};
          }
          .lookFilled-1Gx00P.colorBrand-3pXr91 {
            background-color: ${settings1.AccentColor} ${settings1.important};
            border-radius: 10px;
          }
          #bd-settingspane-container .ui-switch-item .ui-switch-wrapper .ui-switch.checked {
            background-color: ${settings1.AccentColor} ${settings1.important};
          }
          .bda-slist .bda-footer button {
            background-color: ${settings1.AccentColor} ${settings1.important};
          }
          .bd-pfbtn {
            background-color: ${settings1.AccentColor} ${settings1.important};
          }
          .theme-dark .typing-2GQL18 {
            background-color: #252525 ${settings1.important};
          }
          .themeDefault-24hCdX, .sizeDefault-2YlOZr {
            background-color: #1A1919 ${settings1.important};
          }
          .themeDefault-24hCdX.valueChecked-m-4IJZ {
            background-color: ${settings1.AccentColor} ${settings1.important};
          }
          .headerTop-3C2Zn0 {
            background-color: #1A1919 ${settings1.important};
          }
          .message-1PNnaP {
            font-family: ${settings1.MentionedTextFont} ${settings1.important};
          }
          .header-2tA9Os {
            background-color: #222222 ${settings1.important};
          }
          .theme-dark .footer-3rDWdC {
            background-color: #252525 ${settings1.important};
          }
          .theme-dark .markup-2BOw-j a {
            color: ${settings1.LinkColor} ${settings1.important};
          }
          .theme-dark #bd-settings-sidebar .ui-tab-bar-item.selected {
            background-color: ${settings1.AccentColor} ${settings1.important};
          }
          a {
            color: ${settings1.AccentColor} ${settings1.important};
          }
          .checkbox-3kaeSU .checkboxInner-3yjcPe .checkboxElement-1qV33p:checked+span {
            background-color: ${settings1.AccentColor} ${settings1.important};
            border-color: ${settings1.AccentColor} ${settings1.important};
          }
          .header-2o-2hj, .header-2o-2hj:hover, .clickable-2ap7je:hover  {
            background-color: #101010 ${settings1.important};
          }
          .container-3baos1 {
            background-color: #101010 ${settings1.important};
          }
          .unreadBar-3YD_k9 {
            background-color: ${settings1.UnreadMessagesWrapper} ${settings1.important};
          }
          .modeUnread-1zpFdA {
            color: white ${settings1.important};
          }
          .theme-dark .wrapper-3WhCwL {
            color: ${settings1.ChannelColor} ${settings1.important};
            background-color: ${settings1.ChannelBackground} ${settings1.important};
          }
          .theme-dark .wrapper-3WhCwL:hover {
            background-color: rgba(224, 1, 1, 0.774) ${settings1.important};
          }
          .inner-zqa7da {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .BDFDB-modal .tabBarContainer-1s1u-z {
            background-color: #1A1919 ${settings1.important};
          }
          .inner-ZyuQk0 {
            background-color: #222222 ${settings1.important};
          }
          .newMessagesBar-mujexs {
            background-color: ${settings1.AccentColor} ${settings1.important};
          }
          .autocompleteInner-zh20B_ {
            background-color: #1B1B1B ${settings1.important};
          }
          .theme-dark .selectorSelected-1_M1WV {
            background-color: #303030 ${settings1.important};
          }
          .selectable-3dP3y- {
            background-color: #222222 ${settings1.important};
          }
          .contextMenu-HLZMGh {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .header-ykumBX {
            background-color: #1A1919 ${settings1.important};
          }
          .resultsGroup-r_nuzN {
            background-color: #1A1919 ${settings1.important};
          }
          .container-1giJp5 {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .container-2x5lvQ section {
            background-color: #1B1B1B ${settings1.important};
          }
          .theme-dark .container-2x5lvQ .header-2C89wJ {
            background-color: #1A1919 ${settings1.important};
          }
          .container-3cGP6G {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .footer-1kmXd4 {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .searchHeader-1l-wpR {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .datePicker--XZbmJ {
            background-color: #222222 ${settings1.important};
          }
          .theme-dark .calendarPicker-2yf6Ci .react-datepicker {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .focused-2bY0OD {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .calendarPicker-2yf6Ci .react-datepicker__header {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .card-FDVird:before {
            background-color: #1A1919 ${settings1.important};
          }
          .uploadModal-2ifh8j, .uploadModal-2ifh8j .footer-3mqk7D {
            background-color: black ${settings1.important};
          }
          .checkbox-1ix_J3 {
            border-color: ${settings1.AccentColor} ${settings1.important};
          }
          .attachPopout-1n-ZKM {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .footer-1fjuF6 {
            background-color: #1A1919 ${settings1.important};
          }
          .theme-dark .body-3iLsc4 {
            background-color: #222222 ${settings1.important};
          }
          .theme-dark .quickMessage-1yeL4E {
            background-color: #1B1B1B ${settings1.important};
          }
          .role-2irmRk {
            cursor: default;
            display: flex;
            flex-direction: row;
            height: 20px;
            line-height: 20px;
            margin: 0 4px 5px 0;
            padding: 0;
            border-width: 0;
            border-style: solid;
            border-radius: 3px;
            position: relative;
            overflow: hidden;
          }
          .role-2irmRk:before {
            opacity: 1;
            content: '';
            display: block;
            height: 27px;
            width: 0;
            border-right-width: 500px;
            border-right-style: solid;
            border-right-color: inherit;
            box-sizing: border-box;
            position: absolute;
            top: -2px;
            left: -2px;
            z-index: 3;
          }
          .role-2irmRk.addButton-pcyyf6 {
            border-color: transparent ${settings1.important};
            cursor: pointer;
            border: 0;
          }
          .role-2irmRk .roleName-32vpEy {
            display: flex;
            order: 1;
            height: inherit;
            margin: 0 6px;
            font-size: 13px;
            font-weight: 500;
            z-index: 4;
          }
          .role-2irmRk .roleCircle-3xAZ1j {
            background-color: transparent ${settings1.important};
            background-image: url(data:image/svg+xml;base64,PHN2ZyBjbGFzcz0icm9sZVJlbW92ZUljb24tMml1MGlFIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMiIgaGVpZ2h0PSIxMiIgdmlld0JveD0iMCAwIDEyIDEyIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0wIDBoMTJ2MTJIMCI+PC9wYXRoPjxwYXRoIGNsYXNzPSJmaWxsIiBmaWxsPSIjZmZmZmZmIiBkPSJNOS41IDMuMjA1TDguNzk1IDIuNSA2IDUuMjk1IDMuMjA1IDIuNWwtLjcwNS43MDVMNS4yOTUgNiAyLjUgOC43OTVsLjcwNS43MDVMNiA2LjcwNSA4Ljc5NSA5LjVsLjcwNS0uNzA1TDYuNzA1IDYiPjwvcGF0aD48L2c+PC9zdmc+);
            background-size: 12px;
            background-position: center;
            background-repeat: no-repeat;
            display: flex;
            order: 2;
            margin: 0 3px 0 0;
            z-index: 5;
            opacity: 0.5;
          }
          .role-2irmRk .roleCircle-3xAZ1j:hover {
            opacity: 1;
          }
          .role-2irmRk .roleCircle-3xAZ1j:not(.roleCircleButton-377y0l) {
            display: none;
          }
          .role-2irmRk .roleCircle-3xAZ1j svg {
            visibility: hidden;
          }
          ::-webkit-scrollbar {
            background-color: #222222 !important;
          }
          ::-webkit-scrollbar-button {
            background-color: #222222;
          }
          ::-webkit-scrollbar-thumb {
            background-color: #1a1919 !important;
            border-radius: 10px !important;
            border-color: #1a1919 !important;
          }
          ::-webkit-scrollbar-track-piece {
            background-color: #222222 !important;
            border-color: #222222 !important;
          }
          .theme-dark .messagesPopout-24nkyi {
            background-color: #222222 ${settings1.important};
          }
          .theme-dark .tierBody-x9kBBp {
            background-color: #222222 ${settings1.important};
          }
          .tierHeaderContent-2-YfvN {
            background-color: #1A1919 ${settings1.important};
          }
          .children-19S4PO:after {
            display: none ${settings1.important};
          }
          .theme-dark .calendarPicker-2yf6Ci .react-datepicker__day--outside-month, .theme-dark .calendarPicker-2yf6Ci .react-datepicker__day.react-datepicker__day--disabled {
            background-color: #131313 ${settings1.important};
          }
          .theme-dark .option-96V44q:after {
            display: none;
          }
          .inner-3ErfOT {
            background-color: #1a1919 ${settings1.important};
          }
          .childWrapper-anI2G9 {
            background-color: #131313 ${settings1.important};
          }
          .theme-dark .option-96V44q.selected-rZcOL-:hover {
            background-color: #131313 ${settings1.important};
          }
          .header-1TOWci {
            background-color: #1A1919 ${settings1.important};
          }
          .container-2jxBbw {
            background-color: #222222 ${settings1.important};
          }
          .modeSelected-1zApJ_ .content-3at_AU, .modeSelected-1zApJ_:hover .content-3at_AU {
            background-color: #101010 ${settings1.important};
          }
          .item-PXvHYJ da-item {
            background-color: ${settings1.AccentColor} ${settings1.important};
          }
          .popout-2iWAc-.popout-googletranslate .themedPopout-1TrfdI {
            background-color: #1A1919 ${settings1.important};     
          }
          .wrapper-1BJsBx.selected-bZ3Lue .childWrapper-anI2G9, .wrapper-1BJsBx:hover .childWrapper-anI2G9 {
            background-color: ${settings1.AccentColor} ${settings1.important};
          }
          .blockquoteDivider-2hH8H6 {
            background-color: ${settings1.BlockQuotes} ${settings1.important};
          }
          #dv-mount {
            background-color: transparent ${settings1.important};
          }
          .animatedContainer-1pJv5C {
            z-index: 10;
          }
          .hasBanner-14PPlG .header-2o-2hj, .hasBanner-14PPlG .header-2o-2hj:hover {
            z-index: 100;
          }
          .jumpButton-3DTcS_ .loading-2bJK5L {
            background-color: #1a1919 ${settings1.important};
          }
          .theme-dark #MemberCount {
              background-color: transparent ${settings1.important};
          }
          .theme-dark .closeButton-1tv5uR, .theme-dark .keybind-KpFkfr {
            border-color: #bbbbbb ${settings1.important};
            color: #bbbbbb ${settings1.important};
          }
          .directionColumn-35P_nr[style="flex: 1 1 auto;"]:not(.videoInner-3OR9J2) {
            background-color: #222222 ${settings1.important};
          }
          .themeDark-3Ap_7i .image-3zK3Wt {
            background-image: url(http://images.clipartpanda.com/crash-clipart-di9K4AMrT.svg) ${settings1.important};
          }
          .bf-toolbar.bf-visible:before, .bf-toolbar.bf-hover:hover:before {
            background-color: #131313 ${settings1.important};
          }
          .bf-toolbar .bf-arrow {
            background-image: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABkAAAAZCAYAAADE6YVjAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAALiIAAC4iAari3ZIAAAAZdEVYdENvbW1lbnQAQ3JlYXRlZCB3aXRoIEdJTVBXgQ4XAAAAB3RJTUUH4wkaDjcw0vCrlAAAAYRJREFUSEvtk71Lw1AUxTNU0cnBwcFBXAQdFHQWF2cHRXB2cHSXov4HdXBwdhBJnYot6OBeU8HJoQiCQ2htu9h8Nh/V89LjKwGLVis45Achefeee3Lv4z0lIeF/oKrqSLlcXuBy8DSbzWXf9x/egOd5V5VKZYqpwWDb9l4QBKH4wQdY11zXXafk5zQajckwDC/p+ynIH2Wz2SGW9IdlWWsw0OklwVa5/JRgGzXTNOdZ+jWlUinlOE6G9TFgdFCtVqeRP2dIgoZMNLBDm94YhjHXarVuWSeBwRNyq5RFCENhTIkE8TO8xiiLA/Ptdrv92pF2QdGFruvjlMUQW4QDcEepBLFHTLtCmaIgloLRaSfdBUIX3e9S1pNCoTCMU3bMMgkaDuGbjkSY4IZxCX5wX6/XlyLBN8Ex38QBqNFCAv9DMUkMdHWSy+VGWdsX4oKiwWtaReASP4tJMhhNmL+gmy3qfwV89uHr4Qkw3UYULBaLi/l8fiJaDAhN02bgO8tlQsKfoCjvD179CqD5kFoAAAAASUVORK5CYII=) !important;
            fill: white ${settings1.important};
          }
          .listeningAlong-30wH70 {
            background-color: #131313 ${settings1.important};
          }
          ::selection {
            background-color: ${settings1.AccentColor};
          }
          .quickswitcher-3JagVE {
            background-color: #1a1919 ${settings1.important};
          }
          .input-2VB9rf {
            background-color: #1B1B1B ${settings1.important};
          }
          .activityPanel-28dQGo, .panel-24C3ux {
            background-color: #1A1919 ${settings1.important};
          `;
          BdApi.injectCSS("BetterDarkThemes", f)
          setTimeout(() => {
            let p1 = document.getElementById("BetterDarkThemes").innerText;
            let p2 = p1.replaceAll("true", "!important")
            BdApi.injectCSS("BetterDarkTheme", p2);
            
          }, 1000);
            setTimeout(() => {
              BdApi.clearCSS("BetterDarkThemes")
            }, 3000);
          
          
          

  }








}

